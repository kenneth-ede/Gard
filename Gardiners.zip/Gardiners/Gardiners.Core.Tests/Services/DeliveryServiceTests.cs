﻿using Gardiners.Core.Data;
using Gardiners.Core.Models;
using Gardiners.Core.Options;
using Gardiners.Core.Services;
using Microsoft.Extensions.Options;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;

namespace Gardiners.Core.Tests.Services
{
    [TestClass]
    public class DeliveryServiceTests
    {
        private Mock<IOptions<DeliveryServiceOptions>> _options;
        private Mock<IPartnerDataStoreFactory> _partnerDataStoreFactory;

        public void Setup(string deliveryPartnerType)
        {
            var options = new DeliveryServiceOptions { DeliveryPartnerType = deliveryPartnerType };
            _options = new Mock<IOptions<DeliveryServiceOptions>>();
            _options.Setup(mock => mock.Value).Returns(options);

            _partnerDataStoreFactory = new Mock<IPartnerDataStoreFactory>();
            _partnerDataStoreFactory.Setup(mock => mock.Create<StandardDeliveryPartnerDataStore>()).Returns(new StandardDeliveryPartnerDataStore());
            _partnerDataStoreFactory.Setup(mock => mock.Create<PremiumDeliveryPartnerDataStore>()).Returns(new PremiumDeliveryPartnerDataStore());
        }

        [TestMethod]
        public void DeliverOrder_StandardBelowOrderLimit_ReturnsDeliverOrderResponseTrue()
        {
            Setup("Standard");

            var orderRequest = new DeliverOrderRequest 
            { 
                DeliveryMode = DeliveryMode.Standard,
                PartnerId = 1,
                OrderTotal = 25
            };

            var deliveryService = new DeliveryService(_options.Object, _partnerDataStoreFactory.Object);

            var actual = deliveryService.DeliverOrder(orderRequest);

            Assert.IsTrue(actual.Success);
        }

        [TestMethod]
        public void DeliverOrder_StandardBelowOrderLimit_ReturnsDeliverOrderResponseFalse()
        {
            Setup("Standard");

            var orderRequest = new DeliverOrderRequest
            {
                DeliveryMode = DeliveryMode.Standard,
                PartnerId = 1,
                OrderTotal = 101
            };

            var deliveryService = new DeliveryService(_options.Object, _partnerDataStoreFactory.Object);

            var actual = deliveryService.DeliverOrder(orderRequest);

            Assert.IsFalse(actual.Success);
        }

        [TestMethod]
        public void DeliverOrder_StandardExpress_ReturnsDeliverOrderResponseFalse()
        {
            Setup("Standard");

            var orderRequest = new DeliverOrderRequest
            {
                DeliveryMode = DeliveryMode.Express,
                PartnerId = 1,
                OrderTotal = 25
            };

            var deliveryService = new DeliveryService(_options.Object, _partnerDataStoreFactory.Object);

            var actual = deliveryService.DeliverOrder(orderRequest);

            Assert.IsFalse(actual.Success);
        }

        [TestMethod]
        public void DeliverOrder_StandardFastTrack_ReturnsDeliverOrderResponseFalse()
        {
            Setup("Standard");

            var orderRequest = new DeliverOrderRequest
            {
                DeliveryMode = DeliveryMode.FastTrack,
                PartnerId = 1,
                OrderTotal = 25
            };

            var deliveryService = new DeliveryService(_options.Object, _partnerDataStoreFactory.Object);

            var actual = deliveryService.DeliverOrder(orderRequest);

            Assert.IsFalse(actual.Success);
        }

        [TestMethod]
        public void DeliverOrder_PremiumExpress_ReturnsDeliverOrderResponseTrue()
        {
            Setup("Premium");

            var orderRequest = new DeliverOrderRequest
            {
                DeliveryMode = DeliveryMode.Express,
                PartnerId = 1,
                OrderTotal = 25
            };

            var deliveryService = new DeliveryService(_options.Object, _partnerDataStoreFactory.Object);

            var actual = deliveryService.DeliverOrder(orderRequest);

            Assert.IsTrue(actual.Success);
        }

        [TestMethod]
        public void Deliver_PremiumStandard_ReturnsDeliverOrderResponseFalse()
        {
            Setup("Premium");

            var orderRequest = new DeliverOrderRequest
            {
                DeliveryMode = DeliveryMode.Standard,
                PartnerId = 1,
                OrderTotal = 25
            };

            var deliveryService = new DeliveryService(_options.Object, _partnerDataStoreFactory.Object);

            var actual = deliveryService.DeliverOrder(orderRequest);

            Assert.IsFalse(actual.Success);
        }

        [TestMethod]
        public void Deliver_PremiumFastTrack_ReturnsDeliverOrderResponseTrue()
        {
            Setup("Premium");

            var orderRequest = new DeliverOrderRequest
            {
                DeliveryMode = DeliveryMode.FastTrack,
                PartnerId = 1,
                OrderTotal = 25
            };

            var deliveryService = new DeliveryService(_options.Object, _partnerDataStoreFactory.Object);

            var actual = deliveryService.DeliverOrder(orderRequest);

            Assert.IsTrue(actual.Success);
        }
    }
}
