﻿using Gardiners.Core.Models;

namespace Gardiners.Core.Data
{
    public class PremiumDeliveryPartnerDataStore : IDeliveryPartnerDataStore
    {
        public virtual DeliveryPartner GetDeliveryPartner(int partnerId)
        {
            // Access premium partners data base to retrieve delivery partner by partner id, code removed for brevity 
            return new DeliveryPartner
            {
                AllowedDeliveryModes = AllowedDeliveryModes.PremiumAllowedDeliveryModes,
                OrderValueLimit = 100,
            };
        }

        public virtual void UpdateDeliveryPartner(DeliveryPartner deliveryPartner)
        {
            // Update partner in premium partners database, code removed for brevity
        }
    }
}
