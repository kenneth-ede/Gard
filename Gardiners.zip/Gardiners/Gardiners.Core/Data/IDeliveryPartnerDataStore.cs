﻿using Gardiners.Core.Models;

namespace Gardiners.Core.Data
{
    public interface IDeliveryPartnerDataStore
    {
        DeliveryPartner GetDeliveryPartner(int partnerId);
        void UpdateDeliveryPartner(DeliveryPartner deliveryPartner);
    }
}