﻿using System;

namespace Gardiners.Core.Data
{
    public class PartnerDataStoreFactory : IPartnerDataStoreFactory
    {
        public IDeliveryPartnerDataStore Create<T>()
        {
            if (typeof(T) == typeof(PremiumDeliveryPartnerDataStore))
                return new PremiumDeliveryPartnerDataStore();

            if (typeof(T) == typeof(StandardDeliveryPartnerDataStore))
                return new StandardDeliveryPartnerDataStore();

            throw new InvalidOperationException();
        }
    }
}
