﻿using Gardiners.Core.Models;

namespace Gardiners.Core.Data
{
    public class StandardDeliveryPartnerDataStore : IDeliveryPartnerDataStore
    {
        public DeliveryPartner GetDeliveryPartner(int partnerId)
        {
            // Access standard partners database to retrieve delivery partner by partner id, code removed for brevity 
            return new DeliveryPartner
            {
                AllowedDeliveryModes = AllowedDeliveryModes.StandardAllowedDeliveryModes,
                OrderValueLimit = 50,
            };
        }

        public void UpdateDeliveryPartner(DeliveryPartner deliveryPartner)
        {
            // Update partner in standard partners database, code removed for brevity
        }
    }
}
