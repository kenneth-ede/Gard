﻿namespace Gardiners.Core.Data
{
    public interface IPartnerDataStoreFactory
    {
        IDeliveryPartnerDataStore Create<T>();
    }
}