﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Gardiners.Core.Models
{
    public class DeliverOrderResponse
    {
        public bool Success { get; set; }
    }
}
