﻿namespace Gardiners.Core.Models
{
    public class DeliveryPartner
    {
        public decimal OrderValueLimit { get; set; }
        public Status Status { get; set; }
        public AllowedDeliveryModes AllowedDeliveryModes { get; set; }
        public decimal TotalOrderValueProcessedTillDate { get; internal set; }
    }
}
