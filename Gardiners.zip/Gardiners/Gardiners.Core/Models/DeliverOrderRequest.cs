﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Gardiners.Core.Models
{
    public class DeliverOrderRequest
    {
        public int PartnerId { get; set; }

        public decimal OrderTotal { get; set; }

        public DeliveryMode DeliveryMode { get; set; }
    }
}
