﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Gardiners.Core.Models
{
    public enum Status
    {
        Live,
        Disabled
    }
}
