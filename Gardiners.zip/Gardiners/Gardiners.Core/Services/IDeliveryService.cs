﻿using Gardiners.Core.Models;

namespace Gardiners.Core.Services
{
    public interface IDeliveryService
    {
        DeliverOrderResponse DeliverOrder(DeliverOrderRequest request);
    }
}