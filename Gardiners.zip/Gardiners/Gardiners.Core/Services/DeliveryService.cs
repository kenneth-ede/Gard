﻿using Gardiners.Core.Data;
using Gardiners.Core.Models;
using Gardiners.Core.Options;
using Microsoft.Extensions.Options;

namespace Gardiners.Core.Services
{
    public class DeliveryService : IDeliveryService
    {
        private readonly DeliveryServiceOptions _options;
        private readonly IPartnerDataStoreFactory _partnerDataStoreFactory;

        public DeliveryService(IOptions<DeliveryServiceOptions> options, IPartnerDataStoreFactory partnerDataStoreFactory )
        {
            _options = options.Value;
            _partnerDataStoreFactory = partnerDataStoreFactory;
        }

        public DeliverOrderResponse DeliverOrder(DeliverOrderRequest request)
        {
            var partnerDataStore = _options.DeliveryPartnerType switch
            {
                "Premium" => _partnerDataStoreFactory.Create<PremiumDeliveryPartnerDataStore>(),
                _ => _partnerDataStoreFactory.Create<StandardDeliveryPartnerDataStore>()
            };

            var deliveryPartner = partnerDataStore.GetDeliveryPartner(request.PartnerId);

            if (deliveryPartner == null)
                return new DeliverOrderResponse { Success = false };

            var success = request.DeliveryMode switch
            {
                DeliveryMode.FastTrack => deliveryPartner.AllowedDeliveryModes.HasFlag(AllowedDeliveryModes.FastTrack),
                DeliveryMode.Standard => deliveryPartner.AllowedDeliveryModes.HasFlag(AllowedDeliveryModes.Standard) && deliveryPartner.OrderValueLimit >= request.OrderTotal,
                DeliveryMode.Express => deliveryPartner.AllowedDeliveryModes.HasFlag(AllowedDeliveryModes.Express) && deliveryPartner.Status == Status.Live,
                _ => false
            };

            if (success)
            {
                deliveryPartner.TotalOrderValueProcessedTillDate += request.OrderTotal;

                partnerDataStore.UpdateDeliveryPartner(deliveryPartner);
            }

            return new DeliverOrderResponse { Success = success };
        }
    }
}