﻿namespace Gardiners.Core.Options
{
    public class DeliveryServiceOptions
    {
        public string DeliveryPartnerType { get; set; }
    }
}
